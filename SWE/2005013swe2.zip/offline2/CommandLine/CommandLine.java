package CommandLine;

import FileSystem.FileSystem;
import FileSystem.MyFolder;
import FileSystem.MyFile;
import FileSystem.MyRoot;
import FileSystem.MyDrive;
import FileSystem.Directory;

public class CommandLine {
    private Directory currentDirectory;
    private final MyRoot root;
    public CommandLine(){
        root=new MyRoot();
        currentDirectory=root;
    }
    public void changeDirectory(String name){
        if(name.charAt(name.length()-1)!='\\'){
           name = name.concat("\\");
        }

        name=currentDirectory.getDirectory()+name;
        FileSystem directory=currentDirectory.findDirectory(name);
        if(directory!=null){
            Directory valid=currentDirectory.getValidDirectory(name);
            if(valid==null){
                System.out.println("File cannot be a directory.");
            }else{
                currentDirectory=valid;
            }
        }  else {
            System.out.println("Couldn't find directory.");
        }
    }

    public void showDetails(String name){

            if(name.charAt(name.length()-1)!='\\'){
                name = name.concat("\\");
            }
            name = currentDirectory.getDirectory() + name;
            FileSystem directory = currentDirectory.findDirectory(name);
            if (directory != null) {
                directory.showDetails();
            } else {
                System.out.println("Couldn't find directory.");
            }
    }
    public void showList(){
            currentDirectory.showList();
    }
    public void recursiveDelete(String name){
        if(name.charAt(name.length()-1)!='\\'){
            name = name.concat("\\");
        }
        name=currentDirectory.getDirectory()+name;
        FileSystem directory=currentDirectory.findDirectory(name);
        if(directory != null){
            boolean success=currentDirectory.deleteRecursively(name);
            if(!success){
                System.out.println("Couldn't delete folder");
            }
        }else {
            System.out.println("Couldn't find directory.");
        }
    }
    public void Delete(String name){
        if(name.charAt(name.length()-1)!='\\'){
            name = name.concat("\\");
        }
        name=currentDirectory.getDirectory()+name;
        FileSystem directory=currentDirectory.findDirectory(name);
        if(directory != null){
            boolean success=currentDirectory.Delete(name);
            if(!success) {
                System.out.println("Can't delete . Must be an empty "+directory.getType());
            }
        }else {
            System.out.println("Couldn't find directory.");
        }

    }

    public void jumpToRoot(){
        currentDirectory=root;
    }
    public void makeDirectory(String name){
        String tmp=currentDirectory.getDirectory()+name.concat("\\");
        FileSystem directory=currentDirectory.findDirectory(tmp);
        if(directory == null) {
            MyFolder fd=new MyFolder(name);
            boolean success=currentDirectory.addFolder(fd);
            if(!success){
                System.out.println("can't create folder in "+currentDirectory.getType());
            }
        }else{
            System.out.println("name already exists");
        }
    }

    public void makeFile(String name, Double sz){
        String tmp=currentDirectory.getDirectory()+name.concat("\\");        FileSystem directory=currentDirectory.findDirectory(tmp);
        if(directory == null) {
            MyFile fd=new MyFile(name,sz);
            boolean success=currentDirectory.addFile(fd);
            if(!success){
                System.out.println("can't create file in "+currentDirectory.getType());
            }
        }else{
            System.out.println("name already exists");
        }

    }
    public void makeDrive(String name){
        name=name.concat(":");
        String tmp=currentDirectory.getDirectory()+name.concat("\\");        FileSystem directory=currentDirectory.findDirectory(tmp);
        if(directory == null) {
            MyDrive fd = new MyDrive(name);
            boolean success = currentDirectory.addDrive(fd);
            if (!success) {
                System.out.println("can't create drive in " + currentDirectory.getType());
            }
        }else{
            System.out.println("name already exists");
        }
    }

}
