package FileSystem;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MyFile extends FileSystem {
    public MyFile(String name, Double size){
        this.setComponentCount(0);
        this.setType("File");
        this.setName(name);
        this.setSize(size);
        this.setDirectory("");
        this.setCreationTime(LocalDateTime.now());
    }

    public FileSystem findDirectory(String dir){
        if(this.getDirectory().equalsIgnoreCase(dir)){
            return this;
        }
        return null;
    }

    @Override
    public Double calculateSize() {
        return this.size;
    }
    public void showDetails(){
        System.out.println("Name: "+this.name);
        System.out.println("Type: "+this.type);
        System.out.println("Size: "+this.size+" kB");
        System.out.println("Directory: "+this.directory);
        System.out.println("Component Count: "+this.componentCount);
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd MMMM,yyyy HH:mm a");
        System.out.println("Creation Time: "+dtf.format(this.creationTime));
        System.out.println();
    }

    @Override
    public boolean isLeaf() {
        return true;
    }


}
