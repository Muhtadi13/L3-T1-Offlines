package FileSystem;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public abstract class Directory extends FileSystem{
    protected ArrayList<FileSystem> childDirectories;
    public Directory(){
        childDirectories=new ArrayList<>();
        setDirectory("");
    }
    public FileSystem findDirectory(String dir){

        if (this.getDirectory().equalsIgnoreCase(dir)) {
            return this;
        }
        for (FileSystem dr : childDirectories) {
            if (dir.toLowerCase().startsWith(dr.getDirectory().toLowerCase())) {
                return dr.findDirectory(dir);
            }
        }
        return null;

    }
    public Double calculateSize() {
        Double sum = 0.0;
        for(FileSystem dr: childDirectories){
            sum+=dr.calculateSize();
        }
        return sum;
    }
    public void showDetails(){
        System.out.println("Name: "+this.name);
        System.out.println("Type: "+this.type);
        System.out.println("Size: "+calculateSize()+" kB");
        System.out.println("Directory: "+this.directory);
        System.out.println("Component Count: "+this.componentCount);
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd MMMM,yyyy HH:mm a");
        System.out.println("Creation Time: "+dtf.format(this.creationTime));
        System.out.println();
    }
    public void showList(){
        DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm:ss");
        for(FileSystem dr: childDirectories){
            System.out.println(dr.getName()+" "+dr.calculateSize()+"kB "+dtf.format(dr.getCreationTime()));
        }
    }
    public boolean Delete(String dir){
        for(FileSystem dr: childDirectories){
            if(dir.equalsIgnoreCase(dr.getDirectory())){
                if((dr instanceof MyFile) || dr.getComponentCount()==0) {
                    childDirectories.remove(dr);
                    return true;
                }
                return false;
            }else if(dir.toLowerCase().startsWith(dr.getDirectory().toLowerCase())){
                return ((Directory) dr).Delete(dir);
            }
        }
        return false;
    }
    private void recursiveDelete(){
        while(childDirectories.size()>0){
            FileSystem fd=childDirectories.get(0);
            if(fd instanceof Directory){
                ((Directory) fd).recursiveDelete();
            }
            childDirectories.remove(fd);
        }
    }
    public boolean deleteRecursively(String dir){
        for(FileSystem dr: childDirectories){
            if(dir.equalsIgnoreCase(dr.getDirectory())){
                if(dr instanceof Directory) {
                    ((Directory) dr).recursiveDelete();
                }else {
                    System.out.println("Warning : Deleting a File");
                }
                childDirectories.remove(dr);
                return true;
            }else if(dir.toLowerCase().startsWith(dr.getDirectory().toLowerCase())){
                return ((Directory) dr).deleteRecursively(dir);
            }
        }
        return false;
    }
    public Directory getValidDirectory(String dir){
        for(FileSystem dr: childDirectories){
            if(dir.equalsIgnoreCase(dr.getDirectory())){
                if((dr instanceof MyFile)) {
                    return null;
                }
                System.out.println(dr.getDirectory()+" is current directory");
                return (Directory) dr;

            }else if(dir.toLowerCase().startsWith(dr.getDirectory().toLowerCase())){
                return ((Directory) dr).getValidDirectory(dir);
            }
        }
        return null;
    }




    public boolean isLeaf(){
        return false;
    }
    public abstract boolean addFile(MyFile dr);
    public abstract boolean addFolder(MyFolder dr);
    public abstract boolean addDrive(MyDrive dr);
}
