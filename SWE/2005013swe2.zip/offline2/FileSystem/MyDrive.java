package FileSystem;

import java.time.LocalDateTime;

public class MyDrive extends Directory {
    public MyDrive(String name){

        this.setComponentCount(0);
        this.setType("Drive");
        this.setName(name);
        this.setSize(0.0);
        this.setDirectory("");
        this.setCreationTime(LocalDateTime.now());
    }

    @Override
    public boolean addFile(MyFile dr) {
        if(this.getDirectory().length()==0){
            dr.setDirectory(dr.getName()+"\\");
        }else{
            dr.setDirectory(this.getDirectory()+dr.getName()+"\\");
        }
        this.childDirectories.add(dr);
        this.componentCount++;
        return true;
    }

    @Override
    public boolean addFolder(MyFolder dr) {
        if(this.getDirectory().length()==0){
            dr.setDirectory(dr.getName()+"\\");
        }else{
            dr.setDirectory(this.getDirectory()+dr.getName()+"\\");
        }
        this.childDirectories.add(dr);
        this.componentCount++;
        return true;
    }

    @Override
    public boolean addDrive(MyDrive dr) {
        return false;
    }
}
