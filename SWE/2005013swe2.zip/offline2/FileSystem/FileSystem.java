package FileSystem;
import java.time.LocalDateTime;
public abstract class FileSystem {
    protected String name;
    protected Double size;
    protected String type;
    protected String directory;
    protected Integer componentCount;
    protected LocalDateTime creationTime;
    public void setSize(Double size) {
        this.size = size;
    }

    public LocalDateTime getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(LocalDateTime creationTime) {
        this.creationTime = creationTime;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void setType(String type){
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setComponentCount(Integer componentCount) {
        this.componentCount = componentCount;
    }

    public Integer getComponentCount() {
        return componentCount;
    }

    public String getDirectory() {
        return directory;
    }

    public void setDirectory(String directory) {
        this.directory = directory;
    }

    public abstract Double calculateSize();
    public abstract FileSystem findDirectory(String name);
    public abstract void showDetails();
    public abstract boolean isLeaf();
}
