package FileSystem;

import java.time.LocalDateTime;

public class MyRoot extends Directory{

    public MyRoot(){
        this.setComponentCount(0);
        this.setType("Root");
        this.setSize(0.0);
        this.setName("root");
        this.setDirectory("");
        this.setCreationTime(LocalDateTime.now());
    }

    @Override
    public boolean addFile(MyFile dr) {
        return false;
    }

    @Override
    public boolean addFolder(MyFolder dr) {
        return false;
    }

    @Override
    public boolean addDrive(MyDrive dr) {
        if(this.getDirectory().length()==0){
            dr.setDirectory(dr.getName()+"\\");
        }else{
            dr.setDirectory(this.getDirectory()+dr.getName()+"\\");
        }
        this.childDirectories.add(dr);
        this.componentCount++;
        return true;
    }

}
