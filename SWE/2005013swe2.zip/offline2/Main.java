import CommandLine.CommandLine;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CommandLine cmd=new CommandLine();
        Scanner sc=new Scanner(System.in);
        String[] command=sc.nextLine().split(" ");
        while(!command[0].equalsIgnoreCase("end")){
            try {
                if (command[0].equalsIgnoreCase("mkdir")) {
                    cmd.makeDirectory(command[1]);
                } else if (command[0].equalsIgnoreCase("cd")) {
                    if (command[1].equalsIgnoreCase("~")) {
                        cmd.jumpToRoot();
                    } else {
                        cmd.changeDirectory(command[1]);
                    }
                } else if (command[0].equalsIgnoreCase("ls")) {
                    cmd.showDetails(command[1]);
                } else if (command[0].equalsIgnoreCase("list")) {
                    cmd.showList();
                } else if (command[0].equalsIgnoreCase("delete")) {

                    if (command[1].equalsIgnoreCase("-r")) {
                        cmd.recursiveDelete(command[2]);
                    }else {
                        cmd.Delete(command[1]);
                    }
                } else if (command[0].equalsIgnoreCase("touch")) {
                    if(command[2]==null){
                        command[2]="0.0";
                    }
                    cmd.makeFile(command[1], Double.parseDouble(command[2]));
                } else if (command[0].equalsIgnoreCase("mkdrive")) {
                    cmd.makeDrive(command[1]);
                } else {
                    System.out.println("invalid input");
                }
            }catch (Exception e){
                System.out.println("Invalid number of inputs");
            }
            command=sc.nextLine().split(" ");
        }

    }
}