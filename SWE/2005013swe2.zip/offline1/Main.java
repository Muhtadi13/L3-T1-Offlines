import Passenger.Passenger;
import Passenger.Crewmates;
import Passenger.Imposter;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Passenger passenger = null;
        Scanner sc=new Scanner(System.in);
        String[] command=sc.nextLine().split(" ");
        while(!command[0].equalsIgnoreCase("end")){
            try {
                if (command[0].equalsIgnoreCase("login")) {
                    if (command[1].toLowerCase().startsWith("Crew".toLowerCase())) {
                        passenger=new Crewmates(command[1]);
                    } else {
                        passenger=new Imposter(new Crewmates(command[1]));
                    }
                    passenger.login();

                } else if (passenger==null) {
                    System.out.println("Login first");
                } else {
                    if (command[0].equalsIgnoreCase("work")) {
                        passenger.work();
                    } else if (command[0].equalsIgnoreCase("repair")) {
                        passenger.repair();
                    } else if (command[0].equalsIgnoreCase("logout")) {
                        passenger.logout();
                        passenger=null;
                    } else {
                        System.out.println("Invalid command");
                    }
                }
            }catch (Exception e){
                System.out.println("Invalid number of inputs");
            }
            command=sc.nextLine().split(" ");
        }

    }
}