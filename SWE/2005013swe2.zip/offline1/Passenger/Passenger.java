package Passenger;

public interface Passenger {
    void login();
    void repair();
    void work();
    void logout();
}
