package Passenger;

import java.security.PublicKey;

public class Imposter implements Passenger{
   private Passenger passenger;

   public Imposter(Passenger passenger){
       this.passenger=passenger;
   }
    @Override
    public void login() {
       passenger.login();
       imposterLogin();
    }
    @Override
    public void repair() {
       passenger.repair();
       imposterRepair();

    }
    @Override
    public void work() {
       passenger.work();
       imposterWork();

    }
    @Override
    public void logout() {
        passenger.logout();
        imposterLogout();
    }
    private void imposterLogin(){
        System.out.println("We won’t tell anyone; you are an\nimposter.");

    }
    private void imposterRepair(){
        System.out.println("Damaging the spaceship.");

    }
    private void imposterWork(){
        System.out.println("Trying to kill a crewmate.\nSuccessfully killed a crewmate.\n");

    }
    private void imposterLogout(){
        System.out.println("See you again Comrade Imposter.");
    }
}
