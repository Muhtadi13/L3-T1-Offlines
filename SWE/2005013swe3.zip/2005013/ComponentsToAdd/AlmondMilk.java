package ComponentsToAdd;

public class AlmondMilk extends Customization {

    public AlmondMilk() {
        this.price = 60;
        element = IngredientType.ALMOND_MILK;

    }

}
