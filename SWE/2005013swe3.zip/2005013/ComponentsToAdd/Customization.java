package ComponentsToAdd;

public abstract class Customization {
    protected Integer price;
    protected IngredientType element;
    public Integer getPrice(){
        return this.price;
    };

    public IngredientType getElement() {
        return element;
    }
}

