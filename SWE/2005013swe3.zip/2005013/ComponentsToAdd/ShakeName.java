package ComponentsToAdd;

public enum ShakeName {
    CHOCOLATE_SHAKE,COFFEE_SHAKE,STRAWBERRY_SHAKE,
    VANILLA_SHAKE,ZERO_SHAKE
}
