package ComponentsToAdd;

public class Candy extends Customization {

    public Candy() {
        this.price = 50;
        element = IngredientType.CANDY;
    }

}
