package ComponentsToAdd;

public enum SugarType {
    SUGAR,SWEETENER
}
