package ComponentsToAdd;

public class Cookie extends Customization {

    public Cookie() {
        this.price = 40;
        element = IngredientType.COOKIES;
    }

}
