import Builder.Builder;
import ComponentsToAdd.AlmondMilk;
import ComponentsToAdd.Candy;
import ComponentsToAdd.Cookie;
import ComponentsToAdd.Customization;
import Director.Director;
import Shakes.Shake;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("press o to start/e to exit");
        Scanner sc=new Scanner(System.in);
        String command=sc.next();
        Director director=new Director();
        Builder builder=new Builder();
        ArrayList<Shake> shakeArrayList=new ArrayList<>();

            while (!command.equalsIgnoreCase("e")) {
                if (command.equalsIgnoreCase("o")) {
                    //System.out.println("Enter Name of Shake");
                    String name;
                    String addition;

                    ArrayList<Customization> extra = new ArrayList<>();
                    System.out.println("press the number for desired shake");
                    System.out.println("1. chocolate");
                    System.out.println("2. coffee");
                    System.out.println("3. strawberry");
                    System.out.println("4. vanilla");
                    System.out.println("5. zero");
                    name = sc.next();
                    System.out.println("Do you want lactose free milk (Y for YES/any other key for NO) ");

                    addition = sc.next();
                    if (addition.equalsIgnoreCase("y")) {
                        extra.add(new AlmondMilk());
                    }
                    System.out.println("Do you want candy (Y for YES/any other key for NO) ");
                    addition = sc.next();
                    if (addition.equalsIgnoreCase("y")) {
                        extra.add(new Candy());
                    }
                    System.out.println("Do you want Cookie (Y for YES/any other key for NO) ");
                    addition = sc.next();
                    if (addition.equalsIgnoreCase("y")) {
                        extra.add(new Cookie());
                    }
                    if (name.equalsIgnoreCase("1")) {
                        director.buildChocolateShake(builder, extra);
                        shakeArrayList.add(builder.getResult());

                    } else if (name.equalsIgnoreCase("2")) {
                        director.buildCoffeeShake(builder, extra);
                        shakeArrayList.add(builder.getResult());

                    } else if (name.equalsIgnoreCase("3")) {
                        director.buildStrawberryShake(builder, extra);
                        shakeArrayList.add(builder.getResult());

                    } else if (name.equalsIgnoreCase("4")) {
                        director.buildVanillaShake(builder, extra);
                        shakeArrayList.add(builder.getResult());

                    }else if (name.equalsIgnoreCase("5")) {
                        director.buildZeroShake(builder, extra);
                        shakeArrayList.add(builder.getResult());

                    }else {
                        System.out.println("Invalid Shake Name");
                    }
                    System.out.println("Do you want to add more shakes to order(Y for YES/E for exit)");
                    command=sc.next();
                    while (!command.equalsIgnoreCase("y") && !command.equalsIgnoreCase("e")){
                        System.out.println("Wrong command");
                        System.out.println("Do you want to add more shakes to order(Y for YES/E for exit)");
                        command=sc.next();

                    }
                    if(command.equalsIgnoreCase("y")){
                        command="o";
                    }
                }else{
                    System.out.println("Wrong command");
                    System.out.println("press o to start/e to exit");
                    command=sc.next();
                }

            }
            for(Shake shake:shakeArrayList){
                shake.printDetails();
            }


    }
}