package Shakes;

import ComponentsToAdd.Customization;
import ComponentsToAdd.IngredientType;
import ComponentsToAdd.ShakeName;
import ComponentsToAdd.SugarType;

import java.util.ArrayList;

public class Shake {
    private final ShakeName name;
    private final SugarType sugarType;
    private final IngredientType firstIngredient;
    private final IngredientType secondIngredient;
    private final ArrayList<Customization> extra;
    private final Integer basePrice;

    public Shake(ShakeName name,SugarType sugarType,IngredientType firstIngredient,IngredientType secondIngredient,Integer basePrice,ArrayList<Customization> extra){
        this.extra=new ArrayList<>();
        this.name=name;
        this.sugarType = sugarType;
        this.firstIngredient = firstIngredient;
        this.secondIngredient = secondIngredient;
        this.basePrice =basePrice;
        for(Customization c : extra){
            this.extra.add(c);
        }
    }

    public ShakeName getName() {
        return name;
    }

    public SugarType getSugarType() {
        return sugarType;
    }

    public IngredientType getFirstIngredient() {
        return firstIngredient;
    }

    public IngredientType getSecondIngredient() {
        return secondIngredient;
    }

    public ArrayList<Customization> getExtra() {
        return extra;
    }
    private Integer getTotalPrice(){
        Integer tmp=basePrice;
        for(Customization c:extra){
         tmp+=c.getPrice();
        }
        return tmp;
    }
    public void printDetails(){
        //System.out.println("your bill");
        System.out.println(name+"  "+ basePrice);
    if(extra.size()>0)
        //System.out.println("money added for");
        for(Customization c:extra){
            System.out.println(c.getElement()+"  "+c.getPrice());
        }
        System.out.println("-------------------");
        System.out.println("Total      "+ getTotalPrice());
        System.out.println();
    }

}
