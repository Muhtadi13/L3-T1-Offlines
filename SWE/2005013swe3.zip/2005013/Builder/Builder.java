package Builder;

import ComponentsToAdd.Customization;
import ComponentsToAdd.IngredientType;
import ComponentsToAdd.ShakeName;
import ComponentsToAdd.SugarType;
import Shakes.Shake;

import java.util.ArrayList;

public class Builder {
    private ShakeName name;
    private SugarType sugarType;
    private IngredientType firstIngredient;
    private IngredientType secondIngredient;
    private ArrayList<Customization> extra;
    private Integer basePrice;
    public Builder(){
        extra=new ArrayList<>();
        basePrice =0;
    }
    public void setName(ShakeName name) {
        this.name = name;
    }
    public void setSugarType(SugarType sugarType) {
        this.sugarType = sugarType;
    }
    public void setFirstIngredient(IngredientType firstIngredient) {
        this.firstIngredient = firstIngredient;
    }
    public void setSecondIngredient(IngredientType secondIngredient) {
        this.secondIngredient = secondIngredient;
    }
    public void setExtra(ArrayList<Customization> extra) {
        this.extra = extra;
//        for(Customization c:extra){
//            basePrice +=c.getPrice();
//        }
    }
    public void setBasePrice(Integer basePrice) {
        this.basePrice = basePrice;
    }
    public Shake getResult(){
        return new Shake(name,sugarType,firstIngredient,secondIngredient, basePrice,extra);
    }
}
