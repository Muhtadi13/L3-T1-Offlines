package Director;

import Builder.Builder;
import ComponentsToAdd.Customization;
import ComponentsToAdd.IngredientType;
import ComponentsToAdd.ShakeName;
import ComponentsToAdd.SugarType;


import java.util.ArrayList;

public class Director {
    public void buildChocolateShake(Builder builder, ArrayList<Customization> extra){
        builder.setName(ShakeName.CHOCOLATE_SHAKE);
        builder.setFirstIngredient(IngredientType.CHOCOLATE_SYRUP);
        builder.setSugarType(SugarType.SUGAR);
        builder.setSecondIngredient(IngredientType.CHOCOLATE_ICE_CREAM);
        builder.setBasePrice(230);
        builder.setExtra(extra);
    }
    public void buildCoffeeShake(Builder builder, ArrayList<Customization> extra){
        builder.setName(ShakeName.COFFEE_SHAKE);
        builder.setFirstIngredient(IngredientType.COFFEE);
        builder.setSugarType(SugarType.SUGAR);
        builder.setSecondIngredient(IngredientType.JELLO);
        builder.setBasePrice(250);
        builder.setExtra(extra);
    }
    public void buildStrawberryShake(Builder builder, ArrayList<Customization> extra){
        builder.setName(ShakeName.STRAWBERRY_SHAKE);
        builder.setFirstIngredient(IngredientType.STRAWBERRY_SYRUP);
        builder.setSugarType(SugarType.SUGAR);
        builder.setSecondIngredient(IngredientType.STRAWBERRY_ICE_CREAM);
        builder.setBasePrice(200);
        builder.setExtra(extra);
    }
    public void buildVanillaShake(Builder builder, ArrayList<Customization> extra){
        builder.setName(ShakeName.VANILLA_SHAKE);
        builder.setFirstIngredient(IngredientType.VANILLA_FLAVOURING);
        builder.setSugarType(SugarType.SUGAR);
        builder.setSecondIngredient(IngredientType.JELLO);
        builder.setBasePrice(190);
        builder.setExtra(extra);
    }
    public void buildZeroShake(Builder builder, ArrayList<Customization> extra){
        builder.setName(ShakeName.ZERO_SHAKE);
        builder.setFirstIngredient(IngredientType.VANILLA_FLAVOURING);
        builder.setSugarType(SugarType.SWEETENER);
        builder.setSecondIngredient(IngredientType.SUGAR_FREE_JELLO);
        builder.setBasePrice(240);
        builder.setExtra(extra);
    }
}
